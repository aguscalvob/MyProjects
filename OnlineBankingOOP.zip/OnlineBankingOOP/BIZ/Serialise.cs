﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BIZ
{
    public class Serialise
    {
        public string AccountNo { get; set; }
        public string AccountType { get; set; }
        public string SortCode { get; set; }
        public string Balance { get; set; }
        public string ClientID { get; set; }
    }

}
